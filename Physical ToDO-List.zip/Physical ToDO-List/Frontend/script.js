
const API_URL =
    "https://57frb6da0j.execute-api.ap-southeast-2.amazonaws.com";

const taskInput = document.getElementById("taskInput");
const addTaskBtn = document.getElementById("addTaskBtn");

const pendingTasks = document.getElementById("pendingTasks");
const completedTasks = document.getElementById("completedTasks");

let tasks = [];

// API REQUEST FUNCTION
async function apiRequest(path, options = {}) {
    const response = await fetch(`${API_URL}${path}`, {
        ...options,
        headers: {
            "Content-Type": "application/json",
            ...options.headers
        }
    });

    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.error || "API request failed");
    }

    return data;
}

// FETCH ALL TASKS
async function loadTasks() {
    try {
        tasks = await apiRequest("/tasks");
        renderTasks();
    } catch (error) {
        console.error(error);
        alert("Unable to load tasks: " + error.message);
    }
}

// DISPLAY TASKS
function renderTasks() {
    pendingTasks.innerHTML = "";
    completedTasks.innerHTML = "";

    tasks.forEach((task) => {
        const li = document.createElement("li");

        const span = document.createElement("span");
        span.textContent = task.text;

        const actions = document.createElement("div");

        const actionBtn = document.createElement("button");

        if (task.completed) {
            span.classList.add("completed");
            actionBtn.textContent = "Undo";
            actionBtn.onclick = () => toggleTask(task);
            completedTasks.appendChild(li);
        } else {
            actionBtn.textContent = "Done";
            actionBtn.className = "complete-btn";
            actionBtn.onclick = () => toggleTask(task);
            pendingTasks.appendChild(li);
        }

        const deleteBtn = document.createElement("button");
        deleteBtn.textContent = "Delete";
        deleteBtn.className = "delete-btn";
        deleteBtn.onclick = () => deleteTask(task.taskId);

        actions.appendChild(actionBtn);
        actions.appendChild(deleteBtn);

        li.appendChild(span);
        li.appendChild(actions);
    });
}

// ADD TASK
async function addTask() {
    const text = taskInput.value.trim();

    if (!text) {
        alert("Please enter a task!");
        return;
    }

    try {
        await apiRequest("/tasks", {
            method: "POST",
            body: JSON.stringify({ text })
        });

        taskInput.value = "";
        await loadTasks();

    } catch (error) {
        alert("Unable to add task: " + error.message);
    }
}

// COMPLETE / UNDO TASK
async function toggleTask(task) {
    try {
        await apiRequest(
            `/tasks/${encodeURIComponent(task.taskId)}`,
            {
                method: "PUT",
                body: JSON.stringify({
                    completed: !task.completed
                })
            }
        );

        await loadTasks();

    } catch (error) {
        alert("Unable to update task: " + error.message);
    }
}

// DELETE TASK
async function deleteTask(taskId) {
    try {
        await apiRequest(
            `/tasks/${encodeURIComponent(taskId)}`,
            {
                method: "DELETE"
            }
        );

        await loadTasks();

    } catch (error) {
        alert("Unable to delete task: " + error.message);
    }
}

// EVENT LISTENERS
addTaskBtn.addEventListener("click", addTask);

taskInput.addEventListener("keypress", (event) => {
    if (event.key === "Enter") {
        addTask();
    }
});

// INITIAL LOAD
loadTasks();
