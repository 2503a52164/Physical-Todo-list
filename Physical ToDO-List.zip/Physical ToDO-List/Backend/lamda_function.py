
import json
import boto3
import uuid
import os
from datetime import datetime, timezone

# DynamoDB connection
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(os.environ["TABLE_NAME"])


# Standard API response
def response(status, data):
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS"
        },
        "body": json.dumps(data)
    }


# Main Lambda function
def lambda_handler(event, context):

    # Detect HTTP method (HTTP API v2 and REST API)
    method = (
        event.get("httpMethod")
        or event.get("requestContext", {}).get("http", {}).get("method", "GET")
    )

    path_params = event.get("pathParameters") or {}
    task_id = path_params.get("taskId")

    if method == "OPTIONS":
        return response(200, {"message": "OK"})

    try:

        # GET ALL TASKS
        if method == "GET":
            result = table.scan()
            return response(200, result.get("Items", []))

        # ADD TASK
        elif method == "POST":
            body = json.loads(event.get("body") or "{}")

            if not body.get("text", "").strip():
                return response(400, {"error": "Task text is required"})

            task = {
                "taskId": str(uuid.uuid4()),
                "text": body["text"].strip(),
                "completed": False,
                "createdAt": datetime.now(timezone.utc).isoformat()
            }

            table.put_item(Item=task)

            return response(201, task)

        
        # UPDATE TASK
        elif method == "PUT":

            if not task_id:
                return response(400, {"error": "Task ID required"})

            body = json.loads(event.get("body") or "{}")

            updates = []
            expression_values = {}
            expression_names = {}

            if "text" in body:
                updates.append("#taskText = :text")
                expression_values[":text"] = body["text"]
                expression_names["#taskText"] = "text"

            if "completed" in body:
                updates.append("#taskCompleted = :completed")
                expression_values[":completed"] = body["completed"]
                expression_names["#taskCompleted"] = "completed"

            if not updates:
                return response(400, {"error": "No fields to update"})

            result = table.update_item(
                Key={"taskId": task_id},
                UpdateExpression="SET " + ", ".join(updates),
                ExpressionAttributeValues=expression_values,
                ExpressionAttributeNames=expression_names,
                ReturnValues="ALL_NEW"
            )

            return response(200, result["Attributes"])


        # DELETE TASK
        elif method == "DELETE":

            if not task_id:
                return response(400, {"error": "Task ID required"})

            table.delete_item(
                Key={"taskId": task_id}
            )

            return response(200, {
                "message": "Task deleted successfully"
            })

        return response(405, {"error": "Method not allowed"})

    except KeyError as e:
        return response(400, {
            "error": f"Missing field: {str(e)}"
        })

    except Exception as e:
        print("Error:", str(e))

        return response(500, {
            "error": "Internal server error"
        })
